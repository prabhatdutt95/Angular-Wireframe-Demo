import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { LoginService } from './login.service';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
 
  errorMessage: string;
  name:string;
  contactNo:number;
  successMessage: string;
  loginForm: FormGroup;
  constructor(private loginService:LoginService) { }

  ngOnInit() {
  }
  login(){
    this.loginService.login(this.contactNo).subscribe(
      (response)=>{
        this.errorMessage=""
        this.successMessage=response.message;
      },(errorResponse)=>{
        this.successMessage=""
        this.errorMessage=errorResponse.error.message;
      }
    )
  }
  
}
